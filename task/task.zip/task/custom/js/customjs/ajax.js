//ajax request for insert data


// $('#btnadd').on("click",function(e){
// 	e.preventDefault();
// });
$(document).ready(function(){
});
$('#btnadd').click(function(e){
	e.preventDefault();
	let name = $("#nameid").val();
	let email = $("#emailid").val();
	let password = $("#passwordid").val();
	console.log(name);
	
});

